Hey! Before you use any of these commands do note it might break things!
These functions usually just disable origin cooldowns or permanently empower origins.
These functions also control various admin things!!! do not mess with what you dont know!!!
You have been warned!!